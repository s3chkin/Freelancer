﻿using CHUSHKA.Data.Models;

namespace CHUSHKA.Data
{
    public class Order
    {
        public Order()
        {
            this.Products = new HashSet<ProductOrder>();
        }
        public int Id { get; set; }
        public ICollection<ProductOrder> Products { get; set; }
        public string Product { get; set; }
        public bool OrderedOn { get; set; }
        public int ClientId { get; set; }
        public virtual Client Client { get; set; }
    }
}
