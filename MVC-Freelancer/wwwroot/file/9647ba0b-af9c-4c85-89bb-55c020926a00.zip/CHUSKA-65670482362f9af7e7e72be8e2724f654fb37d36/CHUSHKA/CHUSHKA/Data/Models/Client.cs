﻿using Microsoft.AspNetCore.Identity;

namespace CHUSHKA.Data.Models
{
    public class Client : IdentityUser
    {
        public Client()
        {
            this.Orders = new HashSet<Order>();

        }
        public string FullName { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}
