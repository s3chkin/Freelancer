﻿using CHUSHKA.Data;
using CHUSHKA.Data.Models;
using CHUSHKA.Models;
using Microsoft.AspNetCore.Mvc;

namespace CHUSHKA.Controllers
{
    public class ProductController : Controller
    {

        private readonly ApplicationDbContext db;
        private readonly IWebHostEnvironment webHostEnvironment;

        public ProductController(ApplicationDbContext db, IWebHostEnvironment webHostEnvironment)
        {
            this.db = db;
            this.webHostEnvironment = webHostEnvironment;

        }
        public IActionResult Index()
        {
            var model = db.Products.Select(x => new InputProductModel
            {
                Name = x.Name,
                Price = x.Price,
                Description = x.Description,
                Type = (InputProductModel.Type_)x.Type,

            }).ToList();
            return View(model);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();

        }

        [HttpPost]
        public IActionResult Add(InputProductModel model)
        {
            var product = new Product
            {
                Description = model.Description,
                Name = model.Name,
                Price = model.Price,
                Type = (Product.Type_)model.Type,
            };

            db.Products.Add(product);
            db.SaveChanges();

            return this.RedirectToAction("Index");
        }

        public IActionResult ById(int id)
        {
            var model = db.Products.Where(x => id == x.Id).Select(x => new InputProductModel
            {
                Name = x.Name,
                Description = x.Description,
                Price = x.Price,
                Type = (InputProductModel.Type_)x.Type
            }).FirstOrDefault();
            return this.View(model);
        }

        public IActionResult Delete(int id)
        {
            var model = db.Products.Where(x => id == x.Id).Select(x => new InputProductModel
            {
                Name = x.Name,
                Description = x.Description,
                Price = x.Price,
                Type = (InputProductModel.Type_)x.Type
            }).FirstOrDefault();
            return this.View(model);
        }
        public IActionResult DeleteButton(int id)
        {
            var product = db.Products.Where(s => s.Id == id).FirstOrDefault(); //търсене
            db.Products.Remove(product);
            db.SaveChanges();
            return this.RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {

            var product = db.Products.Where(s => s.Id == id).FirstOrDefault();
            var model = new InputProductModel
            {
                Id = product.Id,
                Name = product.Name,
                Price = product.Price,
                Description = product.Description,
                Type = (InputProductModel.Type_)product.Type

            };

            return this.View(model);
        }
        [HttpPost]
        public IActionResult Edit(int id, InputProductModel model) //update
        {
            var job = db.Products.Where(s => s.Id == model.Id).FirstOrDefault(); //търсене
            job.Id = model.Id;
            job.Name = model.Name;
            job.Description = model.Description;
            job.Price = model.Price;
            db.SaveChanges();
            return this.RedirectToAction("Index");
        }

        public IActionResult AllOrders()
        {
            return View();
        }

    }
}
