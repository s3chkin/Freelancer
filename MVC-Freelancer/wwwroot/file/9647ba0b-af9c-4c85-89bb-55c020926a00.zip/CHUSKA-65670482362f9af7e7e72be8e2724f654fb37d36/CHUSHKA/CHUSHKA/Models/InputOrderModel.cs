﻿namespace CHUSHKA.Models
{
    public class InputOrderModel
    {
        public int Id { get; set; }
        public string Product { get; set; }
        public bool OrderedOn { get; set; }
        public int ClientId { get; set; }
    }
}
