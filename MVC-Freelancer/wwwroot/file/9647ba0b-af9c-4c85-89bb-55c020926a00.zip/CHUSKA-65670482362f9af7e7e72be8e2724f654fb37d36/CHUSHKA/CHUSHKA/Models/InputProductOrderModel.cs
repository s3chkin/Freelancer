﻿namespace CHUSHKA.Models
{
    public class InputProductOrderModel
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int OrderId { get; set; }
    }
}
