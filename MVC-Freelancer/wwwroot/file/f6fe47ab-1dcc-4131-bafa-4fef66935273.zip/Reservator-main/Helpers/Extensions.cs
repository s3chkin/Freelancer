﻿namespace Reservator.Helpers
{
    public class Extensions
    {
    }
}
