﻿namespace Reservator.Models
{
    public enum Town
    {
        Shumen=0,
        Varna=1,
        Sofia=2,
    }

}
